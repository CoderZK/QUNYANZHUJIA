//
//  QYZJMineTongYongTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/15.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJMineTongYongTVC : BaseTableViewController
@property(nonatomic,assign)NSInteger type; //1我的报修; 2,我的案例 
@end

NS_ASSUME_NONNULL_END

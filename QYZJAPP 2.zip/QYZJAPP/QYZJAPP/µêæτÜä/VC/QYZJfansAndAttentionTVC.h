//
//  QYZJfansAndAttentionTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/12.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJfansAndAttentionTVC : BaseTableViewController
@property(nonatomic,assign)NSInteger type; //1关注 2 粉丝
@end

NS_ASSUME_NONNULL_END

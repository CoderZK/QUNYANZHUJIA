//
//  QYZJMinePayDetailVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/6.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJMinePayDetailVC : BaseTableViewController
@property(nonatomic,strong)NSString *ID;
@end

NS_ASSUME_NONNULL_END

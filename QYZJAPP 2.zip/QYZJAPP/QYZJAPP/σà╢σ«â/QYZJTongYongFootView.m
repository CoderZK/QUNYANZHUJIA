//
//  QYZJTongYongFootView.m
//  QYZJAPP
//
//  Created by zk on 2019/11/25.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "QYZJTongYongFootView.h"

@implementation QYZJTongYongFootView



@end

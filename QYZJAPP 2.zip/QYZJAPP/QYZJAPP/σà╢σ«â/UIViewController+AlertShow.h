//
//  UIViewController+AlertShow.h
//  FMWXB
//
//  Created by kunzhang on 2017/11/10.
//  Copyright © 2017年 kunzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (AlertShow)
-(void)showAlertWithKey:(NSString *)num message:(NSString *)message;
@end

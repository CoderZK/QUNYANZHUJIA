//
//  QYZJMineYuYueDanTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/12/19.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJMineYuYueDanTVC : BaseTableViewController

@end

NS_ASSUME_NONNULL_END

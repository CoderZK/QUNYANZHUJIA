//
//  QYZJMineZhuYeTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/22.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJMineZhuYeTVC : BaseTableViewController
@property(nonatomic,strong)NSString *ID;
@end

NS_ASSUME_NONNULL_END

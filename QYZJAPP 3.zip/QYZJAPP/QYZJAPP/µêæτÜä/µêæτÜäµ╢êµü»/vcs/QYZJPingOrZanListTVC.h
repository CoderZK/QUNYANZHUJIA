//
//  QYZJPingOrZanListTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/11.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJPingOrZanListTVC : BaseTableViewController
@property(nonatomic,assign)NSInteger type; //0 点赞 1 评论
@end

NS_ASSUME_NONNULL_END

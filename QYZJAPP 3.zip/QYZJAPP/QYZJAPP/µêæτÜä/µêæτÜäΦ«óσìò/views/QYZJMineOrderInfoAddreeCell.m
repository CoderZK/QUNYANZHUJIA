//
//  QYZJMineOrderInfoAddreeCell.m
//  QYZJAPP
//
//  Created by zk on 2019/12/2.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "QYZJMineOrderInfoAddreeCell.h"

@implementation QYZJMineOrderInfoAddreeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.rightImgV.hidden = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

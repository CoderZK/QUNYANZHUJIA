//
//  zkBannerModel.m
//  BYXuNiPan
//
//  Created by zk on 2018/7/30.
//  Copyright © 2018年 kunzhang. All rights reserved.
//

#import "zkBannerModel.h"

@implementation zkBannerModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}
@end

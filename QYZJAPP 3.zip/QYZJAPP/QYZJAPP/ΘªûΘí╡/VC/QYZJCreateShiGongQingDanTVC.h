//
//  QYZJCreateShiGongQingDanTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/25.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJCreateShiGongQingDanTVC : BaseTableViewController
@property(nonatomic,strong)NSString *ID;
@property(nonatomic,strong)NSString *IDTwo;
@property(nonatomic,assign)BOOL isRob;
@property(nonatomic,assign)CGFloat price;
@end

NS_ASSUME_NONNULL_END

//
//  QYZJJiaoFuZiLiaoTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/25.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJJiaoFuZiLiaoTVC : BaseTableViewController

@end

NS_ASSUME_NONNULL_END

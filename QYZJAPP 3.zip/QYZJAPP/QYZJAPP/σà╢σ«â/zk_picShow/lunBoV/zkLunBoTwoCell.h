//
//  zkLunBoTwoCell.h
//  BYXuNiPan
//
//  Created by zk on 2018/7/12.
//  Copyright © 2018年 kunzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface zkLunBoTwoCell : UICollectionViewCell
/** <#注释#> */
@property(nonatomic,strong)UIImageView *imgV;
@end

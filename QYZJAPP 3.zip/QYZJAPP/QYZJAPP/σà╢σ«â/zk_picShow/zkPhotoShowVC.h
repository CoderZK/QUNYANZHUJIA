//
//  zkPhotoShowVC.h
//  weekend
//
//  Created by kunzhang on 17/3/25.
//  Copyright © 2017年 kunZhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface zkPhotoShowVC : UIViewController

-(void)initWithArray:(NSArray *)array index:(NSInteger)index;

@end

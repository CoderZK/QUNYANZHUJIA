//
//  QYZJMineTiXianVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/16.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJMineTiXianVC : BaseViewController
@property(nonatomic,strong)QYZJMoneyModel *dataModel;
@end

NS_ASSUME_NONNULL_END

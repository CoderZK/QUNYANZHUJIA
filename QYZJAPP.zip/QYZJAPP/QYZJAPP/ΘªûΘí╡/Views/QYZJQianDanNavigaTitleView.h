//
//  QYZJQianDanNavigaTitleView.h
//  QYZJAPP
//
//  Created by zk on 2019/11/6.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QYZJQianDanNavigaTitleView : UIView
@property(nonatomic,copy)void(^navigaBlock)(NSInteger index);
@end

NS_ASSUME_NONNULL_END

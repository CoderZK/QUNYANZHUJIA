//
//  QYZJChangeConstructionOneCell.h
//  QYZJAPP
//
//  Created by zk on 2019/11/21.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QYZJChangeConstructionOneCell : UITableViewCell

@property(nonatomic,strong)NSMutableArray<QYZJWorkModel *> *dataArray;
@property(nonatomic,assign)BOOL is_service; // 0 服务方 1 客户

@end

NS_ASSUME_NONNULL_END

//
//  QYZJFaTieTVC.m
//  QYZJAPP
//
//  Created by zk on 2019/11/5.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "QYZJFaTieTVC.h"

@interface QYZJFaTieTVC ()

@end

@implementation QYZJFaTieTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"发帖";
    
}

@end

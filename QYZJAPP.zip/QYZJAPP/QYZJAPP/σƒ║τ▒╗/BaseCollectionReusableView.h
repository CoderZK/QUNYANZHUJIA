//
//  BaseCollectionReusableView.h
//  ShareGo
//
//  Created by kunzhang on 16/4/7.
//  Copyright © 2016年 kunzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseCollectionReusableView : UICollectionReusableView
@property(nonatomic,strong,readonly)UIImageView * bgImageView;
@end

//
//  BaseTableViewHeaderFooterView.h
//  ShareGo
//
//  Created by kunzhang on 16/4/7.
//  Copyright © 2016年 kunzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTableViewHeaderFooterView : UITableViewHeaderFooterView
@property(nonatomic,strong,readonly)UIImageView * bgImageView;
@end

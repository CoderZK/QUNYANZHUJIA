//
//  BaseViewController+PublicMethod.m
//  OneYuanTuan
//
//  Created by kunzhang on 16/12/9.
//  Copyright © 2016年 heJevon. All rights reserved.
//

#import "BaseViewController+PublicMethod.h"



@implementation BaseViewController (PublicMethod)



@end

//
//  BaseViewController.m
//  kunzhang
//
//  Created by kunzhang on 16/10/13.
//  Copyright © 2016年 kunzhang. All rights reserved.
//

#import "BaseViewController.h"
//#import "LogionTVC.h"
typedef void (^Nav)(UIButton *);
typedef void (^Nav2)();

@interface BaseViewController ()
@property (nonatomic, copy)Nav2 leftBlock2;
@property (nonatomic, copy)Nav2 rightBlock2;
@end
@implementation BaseViewController

- (BOOL)shouldAutorotate
{
    return NO;
}
- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationPortrait;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    [SVProgressHUD setDefaultStyle:(SVProgressHUDStyleCustom)];
    [SVProgressHUD setBackgroundColor:[UIColor colorWithWhite:0 alpha:0.7]];
    [SVProgressHUD setForegroundColor:[UIColor whiteColor]];
    [SVProgressHUD setMinimumDismissTimeInterval:1.0];
    [SVProgressHUD setMaximumDismissTimeInterval:2.0];
    
    self.view.backgroundColor=[UIColor whiteColor];
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
    UIBarButtonItem * backItem = [[UIBarButtonItem alloc] init];
    backItem.title = @"";
    [backItem setBackButtonBackgroundImage:[UIImage imageNamed:@"nav_back"] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    self.navigationItem.backBarButtonItem=backItem;
}


//左侧导航条按钮点击
-(void)setNavLeftBtnWithImg:(NSString *)imgName title:(NSString *)title withBlock:(void (^)(UIButton *leftBtn))leftBtn handleBtn:(void (^)())butnClick{
    
    UIButton *leftBtn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn2.frame = CGRectMake(- 20 , 0 , 44 , 44 );
    if (imgName!=nil&&imgName.length>0&&title!=nil&&title.length>0) {
        leftBtn2.frame = CGRectMake(-20, 0, 110, 44);
        leftBtn2.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    }
    imgName = imgName==nil||[imgName isEqual:[NSNull null]]?@"返回":imgName;
    title = title==nil||[title isEqual:[NSNull null]]?@"":title;
    leftBtn2.titleLabel.font = [UIFont systemFontOfSize:15.0];
    [leftBtn2 addTarget : self action : @selector (tapLeftBtn) forControlEvents : UIControlEventTouchUpInside ];//设置按钮点击事件
    [leftBtn2 setTitle:[NSString stringWithFormat:@"%@",title] forState:UIControlStateNormal];
    [leftBtn2 setImage :[UIImage imageNamed:imgName] forState : UIControlStateNormal]; //设置按钮正常状态图片
    [leftBtn2 setImage :[UIImage imageNamed:imgName] forState : UIControlStateSelected ];//设置按钮选中图片
    //    //NSLog(@"+++++++%@",leftBtn2.titleLabel.text);
    UIBarButtonItem *leftBarButon2 = [[ UIBarButtonItem alloc ] initWithCustomView :leftBtn2];
    if (([[[ UIDevice currentDevice ] systemVersion ] floatValue ]>= 7.0 ? 20 : 0 ))
    {
        UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc ]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target : nil
                                           action : nil ];
        negativeSpacer. width = - 20 ;//这个数值可以根据情况自由变化
        self.navigationItem.leftBarButtonItems = @[ negativeSpacer, leftBarButon2 ] ;
        
    } else{
        self.navigationItem.leftBarButtonItem = leftBarButon2;
    }
    
    if (leftBtn) {
        leftBtn(leftBtn2);
    }
    
    self.leftBlock2 = butnClick;
}

//右侧点击按钮
-(void)setNavRightBtnWithImg:(NSString *)imgName title:(NSString *)title withBlock:(void (^)(UIButton *rightBtn))rightBtn handleBtn:(void (^)())butnClick{
    _rightBtn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    _rightBtn2.frame = CGRectMake(-20 , 0 , 60 , 44 );
    if (imgName!=nil&&imgName.length>0&&title!=nil&&title.length>0) {
        _rightBtn2.frame = CGRectMake(-20, 0, 110, 44);
        _rightBtn2.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    }
    title = title==nil||[title isEqual:[NSNull null]]?@"":title;
    [_rightBtn2 addTarget : self action : @selector (tapRightBtn) forControlEvents : UIControlEventTouchUpInside ];//设置按钮点击事件
    [_rightBtn2 setTitle:title forState:UIControlStateNormal];
    _rightBtn2.titleLabel.font = [UIFont systemFontOfSize:14];
    [_rightBtn2 setImage :[UIImage imageNamed:imgName] forState : UIControlStateNormal]; //设置按钮正常状态图片
    [_rightBtn2 setImage :[UIImage imageNamed:imgName] forState : UIControlStateSelected ];//设置按钮选中图片
    UIBarButtonItem *rightBarButon2 = [[ UIBarButtonItem alloc ] initWithCustomView:_rightBtn2];
    if (([[[ UIDevice currentDevice ] systemVersion ] floatValue ]>= 7.0 ? 20 : 0 ))
    {
        UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc ]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target : nil
                                           action : nil ];
        negativeSpacer. width = - 5 ;//这个数值可以根据情况自由变化
        self.navigationItem.rightBarButtonItems = @[ negativeSpacer, rightBarButon2 ] ;
        
    } else{
        self.navigationItem.leftBarButtonItem = rightBarButon2;
    }
    
    rightBtn(_rightBtn2);
    
    self.rightBlock2 = butnClick;
}



- (void)gotoLoginVC {
    
    BaseNavigationController * navc = [[BaseNavigationController alloc] initWithRootViewController:[[QYZhuJiaLoginVC alloc] init]];
    [self presentViewController:navc animated:YES completion:nil];
    
    
}

- (BOOL)isCanUsePhotos {
    
    AVAuthorizationStatus authStatus =  [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (authStatus == AVAuthorizationStatusRestricted || authStatus ==AVAuthorizationStatusDenied)
    {
        //无权限
        return NO;
    }
    return YES;
}
- (BOOL)isCanUsePicture{
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusRestricted ||
        status == PHAuthorizationStatusDenied) {
        //无权限
        return NO;
    }
    return YES;
}


- (void)getUserBaseicInfo {
    zkRequestTongYongTool * tool = [[zkRequestTongYongTool alloc] init];
    [tool requestWithUrl:[QYZJURLDefineTool user_basicInfoURL] andDict:@{}];
    tool.subject = [[RACSubject alloc] init];
    @weakify(self);
    [tool.subject subscribeNext:^(id  _Nullable x) {
           @strongify(self);
           if (x !=nil && [x[@"key"] intValue] == 1) {
               [zkSignleTool shareTool].role = [[NSString stringWithFormat:@"%@",x[@"result"][@"role"]] intValue];
              
           }else {
               [SVProgressHUD dismiss];
           }
    }];
}

- (void)seysTemparam {
    
      NSMutableDictionary * dict = @{}.mutableCopy;
      dict[@"key"] = @"manner,houseModel,renovationTime,ptkfyy";
      [zkRequestTool networkingPOST:[QYZJURLDefineTool app_systemParamURL] parameters:dict success:^(NSURLSessionDataTask *task, id responseObject) {
          if ([[NSString stringWithFormat:@"%@",responseObject[@"key"]] integerValue] == 1) {
              
              for (NSDictionary * dict in responseObject[@"result"]) {
                  if ([dict[@"key"] isEqualToString:@"ptkfyy"]) {
                      [zkSignleTool shareTool].questMoney = [NSString stringWithFormat:@"%@",dict[@"value"]];;
                  }
                  if ([dict[@"key"] isEqualToString:@"manner"]) {
                      [zkSignleTool shareTool].mannerArr = [[NSString stringWithFormat:@"%@",dict[@"value"]] componentsSeparatedByString:@","];
                  }
                  if ([dict[@"key"] isEqualToString:@"houseModel"]) {
                      [zkSignleTool shareTool].houseModelArr = [[NSString stringWithFormat:@"%@",dict[@"value"]] componentsSeparatedByString:@","];
                  }
                  if ([dict[@"key"] isEqualToString:@"renovationTime"]) {
                      [zkSignleTool shareTool].renvoationTimeArr = [[NSString stringWithFormat:@"%@",dict[@"value"]] componentsSeparatedByString:@","];
                  }
              }
          }else {
              [self showAlertWithKey:[NSString stringWithFormat:@"%@",responseObject[@"key"]] message:responseObject[@"message"]];
              
          }
      } failure:^(NSURLSessionDataTask *task, NSError *error) {
          
      }];
}


- (BOOL)isCanChoose {
    if ([zkSignleTool shareTool].mannerArr.count == 0) {
        [SVProgressHUD showErrorWithStatus:@"获取中,请先完善其它内容"];
        [self seysTemparam];
        return NO;
    }else {
        return YES;
    }
    
    
}


@end

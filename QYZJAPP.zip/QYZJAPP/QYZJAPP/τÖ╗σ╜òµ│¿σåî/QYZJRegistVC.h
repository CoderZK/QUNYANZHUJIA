//
//  QYZJRegistVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/4.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJRegistVC : BaseViewController

@end

NS_ASSUME_NONNULL_END

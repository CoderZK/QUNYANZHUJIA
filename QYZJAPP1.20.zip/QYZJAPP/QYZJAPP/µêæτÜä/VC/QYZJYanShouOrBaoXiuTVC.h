//
//  QYZJYanShouOrBaoXiuTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/28.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJYanShouOrBaoXiuTVC : BaseTableViewController
@property(nonatomic,assign)NSInteger type; // 2 验收 3 报修
@end

NS_ASSUME_NONNULL_END

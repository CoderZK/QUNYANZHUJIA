//
//  QYZJMineCollectTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/13.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJMineCollectTVC : BaseTableViewController

@end

NS_ASSUME_NONNULL_END

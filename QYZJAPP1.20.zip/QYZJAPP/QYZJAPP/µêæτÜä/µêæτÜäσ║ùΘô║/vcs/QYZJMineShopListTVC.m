//
//  QYZJMineShopListTVC.m
//  QYZJAPP
//
//  Created by zk on 2019/11/12.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "QYZJMineShopListTVC.h"

@interface QYZJMineShopListTVC ()

@end

@implementation QYZJMineShopListTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end

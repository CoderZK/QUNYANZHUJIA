//
//  QYZJShopDetailTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/26.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJShopDetailTVC : BaseTableViewController
@property(nonatomic,strong)NSString *ID;
@property(nonatomic,assign)NSInteger isMine;
@end

NS_ASSUME_NONNULL_END

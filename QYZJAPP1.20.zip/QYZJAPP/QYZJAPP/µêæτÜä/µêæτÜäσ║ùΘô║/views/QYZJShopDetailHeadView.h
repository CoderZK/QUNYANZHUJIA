//
//  QYZJShopDetailHeadView.h
//  QYZJAPP
//
//  Created by zk on 2019/11/26.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QYZJShopDetailHeadView : UIView
@property(nonatomic,strong)QYZJFindModel *dataModel;
@property(nonatomic,assign)CGFloat headHeight;
@end

NS_ASSUME_NONNULL_END

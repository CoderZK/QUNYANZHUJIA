//
//  QYZJMineInviteVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/15.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJMineInviteVC : BaseViewController
@property(nonatomic,strong)NSString *invitation_code;
@end

NS_ASSUME_NONNULL_END

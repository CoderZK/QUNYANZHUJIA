//
//  QYZJSettingTVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/11.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseTableViewController.h"



NS_ASSUME_NONNULL_BEGIN

@interface QYZJSettingTVC : BaseTableViewController
@property(nonatomic,strong)QYZJUserModel *dataModel;
@end

NS_ASSUME_NONNULL_END

//
//  QYZJTongYongHeadFootView.h
//  QYZJAPP
//
//  Created by zk on 2019/11/7.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QYZJTongYongHeadFootView : UITableViewHeaderFooterView
@property(nonatomic,strong)UILabel *leftLB;
@property(nonatomic,strong)UIButton *rightBt;
@property(nonatomic,strong)UIView *lineV;
@end

NS_ASSUME_NONNULL_END

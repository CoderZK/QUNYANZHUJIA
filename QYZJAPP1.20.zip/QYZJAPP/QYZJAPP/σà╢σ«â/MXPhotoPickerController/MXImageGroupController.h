//
//  MXImageGroupController.h
//  MXPhotoPickerController
//
//  Created by 韦纯航 on 15/12/9.
//  Copyright © 2015年 韦纯航. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MXImageGroupController : UITableViewController






@end

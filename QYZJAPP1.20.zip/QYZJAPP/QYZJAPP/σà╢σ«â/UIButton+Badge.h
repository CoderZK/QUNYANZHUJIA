//
//  UIButton+Badge.h
//  测试
//
//  Created by 李炎 on 16/9/2.
//  Copyright © 2016年 李炎. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Badge)

- (void)setBadge:(NSString *)number andFont:(int)font;

- (void)setNumber:(NSString *)number andFont:(int )font;



@end

//
//  QYZJFindPasswordTwoVC.h
//  QYZJAPP
//
//  Created by zk on 2019/11/5.
//  Copyright © 2019 kunzhang. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QYZJFindPasswordTwoVC : BaseViewController
@property(nonatomic,strong)NSString *phoneStr;
@end

NS_ASSUME_NONNULL_END
